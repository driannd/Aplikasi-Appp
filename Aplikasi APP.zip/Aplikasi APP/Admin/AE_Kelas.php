<?php 
include "../koneksi.php";
$id_kelas = $_POST['id_kelas'];
$nama_kelas = $_POST['nama_kelas'];
$program_keahlian = $_POST['program_keahlian'];

mysqli_query($koneksi,"UPDATE kelas SET nama_kelas='$nama_kelas', program_keahlian='$program_keahlian' WHERE id_kelas='$id_kelas' ");

header("location:CRUD-Kelas.php?pesan=update");
?>
