<?php
include "../Template-SPP/Header.php";
include "../Template-SPP/Navbar.php";
include "../Template-SPP/Sidebar.php";
?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="row">
            <div class="col">
                <div class="card card-statistic-2">
                    <div class="card-stats">
                        <div class="card-stats-title text-center">
                            <h1>Data Petugas</h1>
                        </div>
                    </div>
                </div>
            </div>   
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Data Petugas</h4>
                        <div class="card-header-action">
                            <a href="T-Petugas.php" class="btn btn-primary">Tambah Data Petugas
                                <i class="fas fa-chevron-right"></i>
                            </a>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive table-invoice">
                            <table class="table table-striped text-center">
                                <tr>
                                    <th>Id Petugas</th>
                                    <th>Username</th>
                                    <th>Password</th>
                                    <th>Nama Petugas</th>
                                    <th>Level</th>
                                    <th>Action</th>
                                </tr>
                                <?php 
                                include "../koneksi.php";
                                $query_mysql = mysqli_query($koneksi,"select * from petugas");
                                $nomor = 1;
                                while($data = mysqli_fetch_array($query_mysql)){
                                ?>
                                <tr>
                                    <td><?php echo $data['id_petugas']; ?></td>
                                    <td class="font-weight-600"><?php echo $data['username']; ?></td>
                                    <td>
                                        <div class="badge badge-warning"><?php echo $data['password']; ?></div>
                                    </td>
                                    <td><?php echo $data['nama_petugas']; ?></td>
                                    <td><?php echo $data['level']; ?></td>
                                    <td>
                                        <a href="E-Petugas.php?id_petugas=<?php echo $data['id_petugas']; ?>" class="btn btn-warning">Edit</a>
                                        <a href="H-Petugas.php?id_petugas=<?php echo $data['id_petugas']; ?>" class="btn btn-danger">Hapus</a>
                                    </td>
                                </tr>
                                <?php } ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<?php include "../Template-SPP/Footer.php"; ?>